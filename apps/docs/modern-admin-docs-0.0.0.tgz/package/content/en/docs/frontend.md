---
title: Frontend
description: ModernAdminProvider, hooks, AdminApp, and customizing components.
---

# Frontend

`@modern-admin/react` provides the React runtime: a provider, hooks for
each REST action, a path-based router (powered by `@tanstack/react-router`
with `createBrowserHistory()`), and a default `<AdminApp />` shell.
`@modern-admin/ui` ships shadcn/ui primitives styled with our theme tokens.

## Provider

```tsx
import { ModernAdminProvider, AdminApp } from '@modern-admin/react'
import '@modern-admin/ui/styles.css'

export default function Root(): React.ReactElement {
  return (
    <ModernAdminProvider apiBaseUrl="/admin/api">
      <AdminApp />
    </ModernAdminProvider>
  )
}
```

The provider creates a `QueryClient` automatically; pass your own with
`queryClient={...}` if you want shared cache across the app.

## Hooks

| Hook                | Purpose                                  |
| ------------------- | ---------------------------------------- |
| `useAdminConfig`    | Read the server-supplied resource config |
| `useResource(id)`   | Look up a single resource descriptor     |
| `useResources()`    | All resources                            |
| `useRecords(id, q)` | Paginated list with filter/sort          |
| `useRecord(id, recId)` | Single record                         |
| `useCreateRecord(id)`  | TanStack mutation                     |
| `useUpdateRecord(id)`  | TanStack mutation                     |
| `useDeleteRecord(id)`  | TanStack mutation                     |

Every hook is a thin wrapper over TanStack Query; compose freely.

## Routing

The admin shell uses `@tanstack/react-router` configured with
`createBrowserHistory()`. URLs are standard path-based (`/resources/:id`),
which means:

- Clean, readable URLs that appear in server-side logs, analytics, and
  deep links from external systems (error trackers, emails, Slack).
- Standard SPA behaviour: the server must return `index.html` for any
  admin path (nginx `try_files $uri /index.html`, Vite
  `preview.historyApiFallback`, or any CDN's SPA redirect rule).
- No SSR. Admin pages are gated by auth and have no SEO needs; the
  browser-history router works without a Node/Nitro server.

URL scheme:

```
/                                          → home
/audit-log                                 → audit log
/resources/:resourceId                     → list
/resources/:resourceId/new                 → create
/resources/:resourceId/:recordId           → show
/resources/:resourceId/:recordId/edit      → edit
/settings                                  → settings hub
/settings/:section                         → settings section (e.g. api-keys)
```

Public API stays high-level: navigation goes through the canonical
`Route` discriminated union, not through TanStack Router's typed paths
directly. This keeps call sites stable across future routing changes.

```ts
import { Link, useNavigate, useRoute, buildHref } from '@modern-admin/react'

// Imperative
const navigate = useNavigate()
navigate({ name: 'edit', resourceId: 'users', recordId: 'u1' })

// Declarative
<Link to={{ name: 'list', resourceId: 'users', query: { page: 2 } }}>
  Page 2
</Link>

// Plain href (e.g. middle-click "open in new tab") — returns '/resources/orders/o1'
const href = buildHref({ name: 'show', resourceId: 'orders', recordId: 'o1' })
```

Search params for the list page (`page`, `perPage`, `sortBy`, `direction`,
and `filters[<path>]=<value>`) are kept opaque to TanStack Router — the
router stores them as a raw string and `useRoute()` reparses them into
`ListQueryState`. This preserves the existing URL format.

## Theming

`@modern-admin/ui/styles.css` exposes shadcn-style HSL CSS variables on
`:root` and `.dark`. Toggle modes via:

```ts
import { initTheme, setThemeMode } from '@modern-admin/ui'

initTheme()              // applies persisted preference, follows system
setThemeMode('dark')     // 'light' | 'dark' | 'system'
```

Override any token to rebrand:

```css
:root {
  --primary: 142 76% 36%;     /* emerald */
  --radius: 0.75rem;
}
```

## Custom components

Replace any property's display/editor with a custom component via
`ComponentLoader`:

```ts
import { ComponentLoader } from '@modern-admin/react'
import { JsonEditor } from './JsonEditor'

const loader = new ComponentLoader()
loader.add('JsonEditor', JsonEditor)

<ModernAdminProvider apiBaseUrl="/admin/api" components={loader}>
  ...
</ModernAdminProvider>
```

Reference the component by name in your resource options:

```ts
{
  id: 'Settings',
  options: {
    properties: {
      payload: { components: { edit: 'JsonEditor', show: 'JsonEditor' } },
    },
  },
}
```

No runtime bundling — components are just regular ES modules imported by
the host app. This keeps cold-start fast and debugging straightforward.
