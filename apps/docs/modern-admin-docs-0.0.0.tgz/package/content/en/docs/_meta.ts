/**
 * Sidebar order for the `/docs/...` section.
 * Keys are filenames (without extension); values are display titles.
 */
export default {
  'getting-started': 'Getting started',
  architecture: 'Architecture',
  decorators: 'Decorators',
  adapters: 'Adapters',
  auth: 'Authentication',
  'admins-and-roles': 'Admins, roles & permissions',
  cache: 'Cache',
  realtime: 'Realtime (WebSocket)',
  graphql: 'GraphQL',
  frontend: 'Frontend',
  openapi: 'OpenAPI & Scalar',
  'ai-assistant-architecture': 'AI assistant architecture',
}
